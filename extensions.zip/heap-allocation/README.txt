heap allocation (approach 1)

what it is: each turn every worker makes new memory for its strip, fills it
and sends it back in the result, distributor puts the strips together

differences from primary (double buffer):
- no second world, job only gets the current world
- worker makes a new strip each turn with makeWorld and adds it to result
- distributor copies strips into a new world, then world = next (no swap,
  old world gets garbage collected)

to run: copy distributor.go over gol/distributor.go then go test ./tests -race
