map-reduce (approach 3)

what it is: one world, workers send cells that need flipping down one
buffered channel, distributor flips them on the world

differences from primary (double buffer):
- no second world and no result struct, just one flips channel
- calculateFlips sends flipped cells instead of writing a new world
- each worker sends a done marker (X = -1) when finished
- distributor collects cells while workers run (stops deadlock), then
  flips them once all are done (so neighbour counts aren't messed up)

to run: copy distributor.go over gol/distributor.go then go test ./tests -race
(set flipBufferSize to 1 to check it doesn't deadlock)
